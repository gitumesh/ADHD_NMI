//
//  SectionFViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 26/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "SectionFViewController.h"
#import "FinalViewController.h"

@interface SectionFViewController ()

@end

@implementation SectionFViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning { 
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionButton:(UIButton*)sender {
    [_buttonYes setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonNo setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [sender setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
    switch (sender.tag) {
        case 0:
            sectionFAnswer = @"1";
            break;
            
        case 1:
            sectionFAnswer = @"0";
            break;
            
        default:
            break;
    }
    [self performSegueWithIdentifier:KSegueShowFinalResult sender:self];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:KSegueShowFinalResult]) {
        FinalViewController *finalViewController = (FinalViewController *)segue.destinationViewController;
        finalViewController.sectionFAnswer = sectionFAnswer;
    }
}


@end
