//
//  SectionFViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 26/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface SectionFViewController : ParentVC{
    NSString *sectionFAnswer;
}

@property (weak, nonatomic) IBOutlet UIButton *buttonYes;
@property (weak, nonatomic) IBOutlet UIButton *buttonNo;


@end
