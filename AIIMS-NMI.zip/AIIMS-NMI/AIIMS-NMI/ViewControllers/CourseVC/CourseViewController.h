//
//  CourseViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface CourseViewController : ParentVC

@property (strong, nonatomic) IBOutlet UIButton *buttonImproving;
@property (strong, nonatomic) IBOutlet UIButton *buttonRegression;


@end
