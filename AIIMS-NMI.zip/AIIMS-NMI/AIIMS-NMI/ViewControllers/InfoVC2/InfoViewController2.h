//
//  InfoViewController2.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"
#import <MessageUI/MessageUI.h>

@interface InfoViewController2 : ParentVC<MFMailComposeViewControllerDelegate>

@end
