//
//  InfoViewController1.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "InfoViewController1.h"

@interface InfoViewController1 ()

@end

@implementation InfoViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [super removeButtomView];
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    // Delay execution of my block for 10 seconds.
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, kDelayTime * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
        [self moveToCaptureVC];
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) moveToCaptureVC{
    [self performSegueWithIdentifier:kSequeShowFirstController sender:self];
    //[self performSegueWithIdentifier:@"testSegue" sender:self];
}

@end
