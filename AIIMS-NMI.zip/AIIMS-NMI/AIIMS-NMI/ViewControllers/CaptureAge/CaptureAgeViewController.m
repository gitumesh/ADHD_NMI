//
//  CaptureAgeViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "CaptureAgeViewController.h"

@interface CaptureAgeViewController ()

@end

@implementation CaptureAgeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [super removeButtomView];
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:kKeyAgeSelected] != nil) {
        _textFieldAge.text = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:kKeyAgeSelected];
//        [self actionContinue:self];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionContinue:(id)sender {
    if ([_textFieldAge.text isEqualToString:@""]) {
        [Utilities showAlertwithTitle:kAlertTitle withMessage:@"Please Enter age to continue" withButtonTitle:kAlertButtonOK withController:self];
    }else{
        [Utilities showAlertwithTitle:kAlertTitle withMessage:[NSString stringWithFormat:@"Entered Age = %@",_textFieldAge.text] withButtonTitle:kAlertButtonOK withHandler:^(UIAlertAction *action) {
            [[NSUserDefaults standardUserDefaults] setValue:_textFieldAge.text forKey:kKeyAgeSelected];
            [self performSegueWithIdentifier:kSequeShowSegueAgeOfOnset sender:self];
        } withController:self];
    }
}



@end
