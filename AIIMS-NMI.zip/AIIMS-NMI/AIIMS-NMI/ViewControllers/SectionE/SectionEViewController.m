//
//  SectionEViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 17/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "SectionEViewController.h"
#import "SectionEResultViewController.h"

@interface SectionEViewController ()

@end

@implementation SectionEViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"SectionEQuestionList" ofType:@"plist"];
    optionForSection = [[NSArray alloc] initWithContentsOfFile:plistPath];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    questionNumber = 0;
    sectionNumber = 0;
    [self setQuestionDetailsForQuestion:questionNumber andSection:sectionNumber];
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}


- (IBAction)actionOptionsClicked:(UIButton*)sender {
    [_buttonOption1 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonOption2 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonOption3 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [sender setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
    if (sender.tag == 0) {
        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber,questionNumber]];
    }else if (sender.tag == 1){
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber,questionNumber]];
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:@"2" forKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber,questionNumber]];
    }
    NSLog(@"SectionESection%dQuestion%d = %@",sectionNumber,questionNumber,[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber,questionNumber]]);
    questionNumber += 1;
    if (questionNumber >= optionForSectionQuestion.count) {
        questionNumber = 0;
        sectionNumber += 1;
        [self.view setUserInteractionEnabled:false];
        if (sectionNumber >= optionForSection.count){
            // Finish Section E
            [self calculateSectionEResult];
        }else{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
                [self setQuestionDetailsForQuestion:questionNumber andSection:sectionNumber ];
            });
        }
    }else{
        [self.view setUserInteractionEnabled:false];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            [self setQuestionDetailsForQuestion:questionNumber andSection:sectionNumber];
        });
    }
}

-(void) setQuestionDetailsForQuestion:(int) questionNumber andSection:(int) sectionNumber{
    [self.view setUserInteractionEnabled:true];
    [_buttonOption1 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonOption2 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonOption3 setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber, questionNumber]] != nil) {
        NSString *stringAnswer = (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", sectionNumber, questionNumber]];
        if ([stringAnswer isEqualToString:@"0"]) {
            [_buttonOption1 setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
//            [self actionOptionsClicked:_buttonOption1];
        }else if ([stringAnswer isEqualToString:@"1"]){
            [_buttonOption2 setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
//            [self actionOptionsClicked:_buttonOption2];
        }else{
            [_buttonOption3 setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
//            [self actionOptionsClicked:_buttonOption3];
        }
    }
    
    _labelQuestionNumberMainSection.text = [NSString stringWithFormat:@"%d. ",sectionNumber+1];
    optionValuesDictionary = [optionForSection objectAtIndex:sectionNumber];
    _labelMainPart.text = (NSString*)[optionValuesDictionary objectForKey:@"SectionName"];
    //NSLog(@"optionValuesDictionary = %@",optionValuesDictionary);
    optionForSectionQuestion = [optionValuesDictionary valueForKey:@"Questions"];
    NSDictionary *questionDictionary = (NSDictionary*)[optionForSectionQuestion objectAtIndex:questionNumber];
    NSArray *answerOptions = (NSArray*)[questionDictionary objectForKey:@"AnswerOptions"];
    if (answerOptions.count <= 2) {
        [_buttonOption3 setHidden:true];
        [_labelOption3 setHidden:true];
    }else{
        [_buttonOption3 setHidden:false];
        [_labelOption3 setHidden:false];
        NSString *labelAnswerOption = (NSString*)[answerOptions lastObject];
        [_labelOption3 setText:labelAnswerOption];
    }
    NSString *labelAnswerOption1 = (NSString*)[answerOptions firstObject];
    [_labelOption1 setText:labelAnswerOption1];
    NSString *labelAnswerOption2 = (NSString*)[answerOptions objectAtIndex:1];
    [_labelOption2 setText:labelAnswerOption2];
    _labelMainQuestion.text = (NSString*)[questionDictionary objectForKey:@"Main"];
    _labelQuestionNumberSectionQuestion.text = (NSString*)[questionDictionary objectForKey:@"Number"];
    _labelSubQuestion.text = (NSString*)[questionDictionary objectForKey:@"Sub"];
}

-(void) methodBack:(id)sender{
    if (questionNumber == 0 && sectionNumber == 0) {
        [super methodBack:self];
    }else if (questionNumber == 0){
        sectionNumber -= 1 ;
        questionNumber = [self getNumberOfQuestionsInSection:sectionNumber] - 1;
        [self setQuestionDetailsForQuestion:questionNumber andSection:sectionNumber];
    }else{
        questionNumber -= 1;
        [self setQuestionDetailsForQuestion:questionNumber andSection:sectionNumber];
    }
}

-(int) getNumberOfQuestionsInSection:(int)sectionNumber{
    NSDictionary* questionDictionary = (NSDictionary*)[optionForSection objectAtIndex:sectionNumber];
    NSArray *questionArray = [questionDictionary objectForKey:@"Questions"];
    return (int)questionArray.count;
}

#pragma mark - Perform Segue

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:KSegueShowSectionEFinalInterpration]) {
        SectionEResultViewController *resultViewController = (SectionEResultViewController *)segue.destinationViewController;
        resultViewController.result = resultFinal;
    }
}

#pragma mark - Calculate Section E result

-(void) calculateSectionEResult{
    /*
     0: No neuromotor dysfunction (Responses to ALL of E1 to E5 is 0)
     1: UMN dysfunction (Any two of following:
     Response to E2 is not zero; Response to 3 is 2 and response to E4 is 1)
     2: LMN dysfunction (Response to E1 is “1”, AND E2 or E3 is “1” AND E4 is not “1”)
     3: In coordination/ Abnormal movements (Response to E5 is “1”)
     9: Indeterminate (If the findings are abnormal but not fitting in any of the above)
     */
    NSString *resultArray = @"";
    NSString* sectionE1;
    NSString* sectionE2;
    NSString* sectionE3;
    NSString* sectionE4;
    NSString* sectionE5;
    
    for(int countSction = 0; countSction < optionForSection.count; countSction++){
        NSArray *arr = (NSArray*)[optionForSection objectAtIndex:countSction];
        for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < arr.count; noOfQuestionsInSection++) {
            resultArray = [resultArray stringByAppendingString:[NSString stringWithFormat:@"Value  = %@\n", [[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", countSction, noOfQuestionsInSection]]]];
        }
        NSString *keyToSave = [NSString stringWithFormat:@"E%d", countSction+1];
        switch (countSction) {
            case 0:{
                sectionE1 = [self calculateSectionE1ResultWithArray:arr];
                //[self setSectionEResultsToDictForKey:keyToSave andValue:sectionE1];
            }
                break;
                
            case 1:{
                sectionE2 = [self calculateSectionE2ResultWithArray:arr];
                //[self setSectionEResultsToDictForKey:keyToSave andValue:sectionE2];
            }
                break;
                
            case 2:{
                sectionE3 = [self calculateSectionE3ResultWithArray:arr];
                //[self setSectionEResultsToDictForKey:keyToSave andValue:sectionE3];
            }
                break;
                
            case 3:{
                sectionE4 = [self calculateSectionE4ResultWithArray:arr];
                //[self setSectionEResultsToDictForKey:keyToSave andValue:sectionE4];
            }
                break;
                
            case 4:{
                sectionE5 = [self calculateSectionE5ResultWithArray:arr];
                //[self setSectionEResultsToDictForKey:keyToSave andValue:sectionE5];
            }
                break;
                
            default:
                break;
        }
    }
    questionNumber = 0;
    sectionNumber = 0;
    [self.view setUserInteractionEnabled:false];
    
    NSString *result = @"";
    if ([sectionE1 isEqualToString:@"0"] && [sectionE2 isEqualToString:@"0"] && [sectionE3 isEqualToString:@"0"] && [sectionE4 isEqualToString:@"0"] && [sectionE5 isEqualToString:@"0"]) {
        result = @"0";
    }else if ([sectionE2 isEqualToString:@"1"] && [sectionE3 isEqualToString:@"2"]){
        result = @"1";
    }else if ([sectionE2 isEqualToString:@"1"] && [sectionE4 isEqualToString:@"1"]){
        result = @"1";
    }else if ([sectionE4 isEqualToString:@"1"] && [sectionE3 isEqualToString:@"2"]){
        result = @"1";
    }else if ([sectionE2 isEqualToString:@"1"] && [sectionE3 isEqualToString:@"2"] && [sectionE4 isEqualToString:@"1"]){
        result = @"1";
    }else if ([sectionE1 isEqualToString:@"1"] && ([sectionE2 isEqualToString:@"1"] || [sectionE3 isEqualToString:@"1"]) && [sectionE4 isEqualToString:@"0"]){
        result = @"2";
    }else if ([sectionE5 isEqualToString:@"1"]){
        result = @"3";
    }else{
        result = @"9";
    }
    
    resultFinal = result;
    
    [Utilities showAlertwithTitle:kAlertTitle withMessage:result withButtonTitle:@"OK" withHandler:^(UIAlertAction *action) {
        [self performSegueWithIdentifier:KSegueShowSectionEFinalInterpration sender:self];
    } withController:self];
}

-(NSString*) calculateSectionE1ResultWithArray:(NSArray*) array{
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 0, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 0, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"0"]) {
                return @"0";
            }
        }
    }
    return @"1";
}

-(NSString*) calculateSectionE2ResultWithArray:(NSArray*) array{
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 1, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 1, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"0"]) {
                return @"0";
            }
        }
    }
    return @"1";
}

-(NSString*) calculateSectionE3ResultWithArray:(NSArray*) array{
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 2, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 2, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"0"]) {
                return @"0";
            }
        }
    }
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 2, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 2, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"1"]) {
                return @"1";
            }
        }
    }
    return  @"2";
}

-(NSString*) calculateSectionE4ResultWithArray:(NSArray*) array{
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 3, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 3, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"1"]) {
                return @"1";
            }
        }
    }
    return  @"0";
}

-(NSString*) calculateSectionE5ResultWithArray:(NSArray*) array{
    for ( int noOfQuestionsInSection = 0; noOfQuestionsInSection < array.count; noOfQuestionsInSection++) {
        if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 4, noOfQuestionsInSection]] != nil) {
            NSString *answerString = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionESection%dQuestion%d", 4, noOfQuestionsInSection]];
            if ([answerString isEqualToString:@"1"]) {
                return @"1";
            }
        }
    }
    return  @"0";
}

//-(void) setSectionEResultsToDictForKey:(NSString *)key andValue:(NSString*)value{
//    if (sectionEResults == nil) {
//        sectionEResults = [[NSDictionary alloc] init];
//    }
//    [sectionEResults setValue:value forKey:key];
//}

@end
