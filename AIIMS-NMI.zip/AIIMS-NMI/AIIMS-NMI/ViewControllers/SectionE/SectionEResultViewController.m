//
//  SectionEResultViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 01/08/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "SectionEResultViewController.h"
#import "SectionFViewController.h"

@interface SectionEResultViewController ()

@end

@implementation SectionEResultViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([_result isEqualToString:@"0"]) {
        [_labelResultE6 setText:@"No neuromotor dysfunction "];
    }else if ([_result isEqualToString:@"1"]){
        [_labelResultE6 setText:@"UMN dysfunction"];
    }else if ([_result isEqualToString:@"2"]){
        [_labelResultE6 setText:@"LMN dysfunction"];
    }else if ([_result isEqualToString:@"3"]){
        [_labelResultE6 setText:@"In coordination/ Abnormal movements "];
    }else if ([_result isEqualToString:@"9"]){
        [_labelResultE6 setText:@"Indeterminate"];
    }
    [[NSUserDefaults standardUserDefaults] setValue:_result forKey:@"SectionEFinalResult"];
}

- (IBAction)actionContinue:(id)sender {
    [self performSegueWithIdentifier:KSegueShowSectionF sender:self];
}

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:KSegueShowSectionF]) {
        SectionFViewController *sectionFViewController = (SectionFViewController *)segue.destinationViewController;
    }
}


@end
