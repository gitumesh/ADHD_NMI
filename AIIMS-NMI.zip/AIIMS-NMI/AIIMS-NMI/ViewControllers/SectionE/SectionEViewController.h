//
//  SectionEViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 17/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface SectionEViewController : ParentVC{
    NSArray * optionForSection;
    NSArray * optionForSectionQuestion;
    NSDictionary *optionValuesDictionary;
    NSString *questionNumberString;
    NSString *question;
    NSString *questionOptions;
    int questionNumber;
    int sectionNumber;
    NSString *resultFinal;
    NSDictionary *sectionEResults;
}

@property (strong, nonatomic) IBOutlet UILabel *labelMainPart;
@property (strong, nonatomic) IBOutlet UILabel *labelMainQuestion;
@property (strong, nonatomic) IBOutlet UILabel *labelSubQuestion;
@property (strong, nonatomic) IBOutlet UIButton *buttonOption1;
@property (strong, nonatomic) IBOutlet UIButton *buttonOption2;
@property (strong, nonatomic) IBOutlet UIButton *buttonOption3;
@property (strong, nonatomic) IBOutlet UILabel *labelOption1;
@property (strong, nonatomic) IBOutlet UILabel *labelOption2;
@property (strong, nonatomic) IBOutlet UILabel *labelOption3;
@property (strong, nonatomic) IBOutlet UILabel *labelQuestionNumberMainSection;
@property (strong, nonatomic) IBOutlet UILabel *labelQuestionNumberSectionQuestion;


@end
