//
//  SectionEResultViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 01/08/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface SectionEResultViewController : ParentVC

@property (nonatomic, retain) NSString *result;
@property (weak, nonatomic) IBOutlet UILabel *labelResultE6;

@end
