//
//  FinalViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 01/08/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface FinalViewController : ParentVC

@property (nonatomic, retain) NSString *sectionFAnswer;
@property (weak, nonatomic) IBOutlet UILabel *labelFinalResult;

@end
