//
//  FinalViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 01/08/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "FinalViewController.h"

@interface FinalViewController ()

@end

@implementation FinalViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [viewBottomView removeFromSuperview];
    viewBottomView = nil;
    [self calculateFinalResult];
}

- (IBAction)actionHome:(id)sender {
    [super methodHome:sender];
}

-(void) calculateFinalResult{
    NSString *ageOnSet = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:kKeyForOnset];
    NSString *course = (NSString *)[[NSUserDefaults standardUserDefaults] valueForKey:kKeyForCourse];
    NSString *sectionEResult = [self getSectionEResult];
    if (![self sectionCResults] && ![self sectionDResults]) {
        [_labelFinalResult setText:@"No Impairment"];
        return;
    }else if ([[self getSectionEResult] isEqualToString:@"0"] && [self sectionCResultsAny1]){
        [_labelFinalResult setText:@"No Impairment"];
        return;
    }else if ([ageOnSet isEqualToString:kAgeOnsetLessThan2] && [course isEqualToString:kCourseImproving] && ([sectionEResult isEqualToString:@"1"] || [sectionEResult isEqualToString:@"3"]) && [_sectionFAnswer isEqualToString:@"0"]){
        [_labelFinalResult setText:@"Cerebral Palsy"];
        return;
    }else if ([sectionEResult isEqualToString:@"2"]){
        [_labelFinalResult setText:@"Neuromuscular Disorder"];
        return;
    }else if ([sectionEResult isEqualToString:@"9"]){
        [_labelFinalResult setText:@"Indeterminate"];
        return;
    }else if (![sectionEResult isEqualToString:@"0"]){
        [_labelFinalResult setText:@"Other Neuromuscular impairment"];
        return;
    }
}

-(BOOL) sectionCResults{
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"SectionCQuestionList" ofType:@"plist"];
    NSArray *values = [[NSArray alloc] initWithContentsOfFile:plistPath];
    BOOL noValueTrue = false;
    for (int i = 0; i < values.count; i++) {
        NSString *returnString = (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionCQuestion%d",i]];
        if ([returnString isEqualToString:@"1"]) {
            return true;
        }
    }
    return noValueTrue;
}

-(BOOL) sectionCResultsAny1{
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"SectionCQuestionList" ofType:@"plist"];
    NSArray *values = [[NSArray alloc] initWithContentsOfFile:plistPath];
    BOOL fails = true;
    int count = 0;
    for (int i = 0; i < values.count; i++) {
        NSString *returnString = (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionCQuestion%d",i]];
        if (![returnString isEqualToString:@"0"]) {
            return false;
        }else{
            count++;
        }
    }
    if (count == values.count) {
        return false;
    }
    return fails;
}

-(BOOL) sectionDResults{
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"SectionDQuestionList" ofType:@"plist"];
    NSArray *values = [[NSArray alloc] initWithContentsOfFile:plistPath];
    BOOL noValueTrue = false;
    for (int i = 0; i < values.count; i++) {
        NSString *returnString = (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionDQuestion%d",i]];
        if ([returnString isEqualToString:@"1"]) {
            return true;
        }
    }
    return noValueTrue;
}

-(NSString *)getSectionEResult{
    return (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:@"SectionEFinalResult"];
}

@end
