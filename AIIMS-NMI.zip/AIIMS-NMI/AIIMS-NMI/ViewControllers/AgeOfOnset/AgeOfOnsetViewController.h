//
//  AgeOfOnsetViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface AgeOfOnsetViewController : ParentVC

@property (strong, nonatomic) IBOutlet UIButton *buttonLessThan2years;
@property (strong, nonatomic) IBOutlet UIButton *buttonGreaterThan2years;


@end
