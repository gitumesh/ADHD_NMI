//
//  AgeOfOnsetViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "AgeOfOnsetViewController.h"

@interface AgeOfOnsetViewController ()

@end

@implementation AgeOfOnsetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    if ([[NSUserDefaults standardUserDefaults] valueForKey:kKeyForOnset] != nil) {
        NSString *stringAgeOnset = (NSString*) [[NSUserDefaults standardUserDefaults] valueForKey:kKeyForOnset];
        if ([stringAgeOnset isEqualToString:kAgeOnsetLessThan2]) {
            [_buttonLessThan2years setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
        }else{
            [_buttonGreaterThan2years setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
        }
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)actionAgeOfOnset:(UIButton*)sender {
    [_buttonLessThan2years setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonGreaterThan2years setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [sender setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
    if (sender.tag == 0) {
        [[NSUserDefaults standardUserDefaults] setValue:kAgeOnsetLessThan2 forKey:kKeyForOnset];
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:kAgeOnsetGreaterThan2 forKey:kKeyForOnset];
    }
    [self.view setUserInteractionEnabled:false];
    [Utilities showAlertwithTitle:kAlertTitle withMessage:[NSString stringWithFormat:@"Onset Age = %@",[[NSUserDefaults standardUserDefaults] valueForKey:kKeyForOnset]] withButtonTitle:kAlertButtonOK withHandler:^(UIAlertAction *action) {
        [self performSegueWithIdentifier:kSequeShowCourse sender:self];
    } withController:self];
    //dispatch_after(dispatch_time(DISPATCH_TIME_NOW, kDelayTime * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
    //    [self performSegueWithIdentifier:kSequeShowCourse sender:self];
    //});
}


@end
