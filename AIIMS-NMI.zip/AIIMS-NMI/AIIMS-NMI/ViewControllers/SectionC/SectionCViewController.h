//
//  SectionCViewController.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "ParentVC.h"

@interface SectionCViewController : ParentVC{
    NSArray * values;
    NSString *questionNumberString;
    NSString *question;
    NSString *questionOptions;
    int questionNumber;
}

@property (strong, nonatomic) IBOutlet UILabel *labelQuestionNumber;
@property (strong, nonatomic) IBOutlet UITextView *textViewQuestionDetails;
@property (strong, nonatomic) IBOutlet UILabel *labelQuestionString;
@property (strong, nonatomic) IBOutlet UIButton *buttonYes;
@property (strong, nonatomic) IBOutlet UIButton *buttonNo;

@end
