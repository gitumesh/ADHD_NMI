//
//  SectionDViewController.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 17/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import "SectionDViewController.h"

@interface SectionDViewController ()

@end

@implementation SectionDViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSString* plistPath = [[NSBundle mainBundle] pathForResource:@"SectionDQuestionList" ofType:@"plist"];
    values=[[NSArray alloc] initWithContentsOfFile:plistPath];
    NSLog(@"arrayValues = %@",values);
    // Do any additional setup after loading the view.
}

-(void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
}

-(void) viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    questionNumber = 0;
    [self setQuestionDetailsForQuestion:questionNumber];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) setQuestionDetailsForQuestion:(int) questionNumber{
    [_buttonYes setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    [_buttonNo setImage:[UIImage imageNamed:@"Selection-Unselected"] forState:UIControlStateNormal];
    
    if ([[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionDQuestion%d",questionNumber]] != nil) {
        NSString *answerString = (NSString*)[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionDQuestion%d",questionNumber]];
        if ([answerString isEqualToString:@"1"]) {
            [_buttonYes setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
            //[self actionSelectedOption:_buttonYes]; //Logio // Comment After Testing
        }else{
            [_buttonNo setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
            //[self actionSelectedOption:_buttonNo]; //Logio // Comment After Testing
        }
    }
    
    NSDictionary* dict = (NSDictionary*)[values objectAtIndex:questionNumber];
    _labelQuestionNumber.text = (NSString*)[dict objectForKey:@"QuestionNumber"];
    _labelQuestionString.text = (NSString*)[dict objectForKey:@"Question"];
    NSString *stringOptions = @"";
    NSArray* options = (NSArray*)[dict valueForKey:@"Options"];
    int optionsNumber = 1;
    for (NSString* string in options) {
        stringOptions = [stringOptions stringByAppendingString:[NSString stringWithFormat:@"%d. %@\n",optionsNumber, string]];
        optionsNumber++;
    }
    stringOptions = [stringOptions stringByTrimmingCharactersInSet:[NSCharacterSet newlineCharacterSet]];
    _textViewQuestionOptions.text = stringOptions;
    [self.view setUserInteractionEnabled:true];
}

- (IBAction)actionSelectedOption:(UIButton *)sender {
    [sender setImage:[UIImage imageNamed:@"Selection-Selected"] forState:UIControlStateNormal];
    if (sender.tag == 0) {
        [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:[NSString stringWithFormat:@"SectionDQuestion%d",questionNumber]];
    }else{
        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:[NSString stringWithFormat:@"SectionDQuestion%d",questionNumber]];
    }
    questionNumber += 1;
    if (questionNumber < values.count) {
        [self.view setUserInteractionEnabled:false];
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^{
            // Perform Segue here
            [self setQuestionDetailsForQuestion:questionNumber];
        });
    }else{
        NSString *stringOfAnsweredQuestions = @"";
        for (int i = 0; i < values.count; i++) {
            stringOfAnsweredQuestions = [stringOfAnsweredQuestions stringByAppendingString:[NSString stringWithFormat:@"Answer to SectionDQuestion%d is %@\n",i,[[NSUserDefaults standardUserDefaults] valueForKey:[NSString stringWithFormat:@"SectionDQuestion%d",i]]]];
        }
        [Utilities showAlertwithTitle:kAlertTitle withMessage:stringOfAnsweredQuestions withButtonTitle:kAlertButtonOK withHandler:^(UIAlertAction *action) {
            [self performSegueWithIdentifier:KSegueShowSectionE sender:self];
        } withController:self];
        //[Utilities showAlertwithTitle:kAlertTitle withMessage:stringOfAnsweredQuestions withButtonTitle:kAlertButtonOK withController:self];
        //[Utilities showAlertwithTitle:kAlertTitle withMessage:@"Click OK when ready." withButtonTitle:kAlertButtonOK withHandler:^(UIAlertAction *action) {
        //    [self performSegueWithIdentifier:KSegueShowSectionE sender:self];
        //} withController:self];
    }
}

-(void) methodBack:(id)sender{
    if (questionNumber == 0) {
        [super methodBack:self];
    }else{
        questionNumber -= 1;
        [self setQuestionDetailsForQuestion:questionNumber];
    }
}

@end
