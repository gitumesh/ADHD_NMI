//
//  main.m
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
