//
//  Constants.h
//  ADHD
//
//  Created by Apple on 06/02/17.
//  Copyright © 2017 Apple. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

typedef enum SelectedChildAge{
    kSelectedChildAgeNone = 1,
    kSelectedChildAgeBelow13,
    kSelectedChildAgeAbove13,
}SelectedChildAge;

#define kKeyForOnset                    @"kKeyOnset"
#define kKeyForCourse                   @"kKeyForCourse"
#define kAgeOnsetLessThan2              @"kAgeOnsetLessThan2"
#define kAgeOnsetGreaterThan2           @"kAgeOnsetGreaterThan2"

#define kCourseImproving                @"kCourseImproving"
#define kCourseRegression               @"kCourseRegression"

#define kSequeShowFirstController       @"moveToNMI"
#define kSequeShowSegueAgeOfOnset       @"SegueAgeOfOnset"
#define kSequeShowCourse                @"moveToCourse"
#define KSegueShowSectionC              @"moveToSectionC"
#define KSegueShowSectionD              @"moveToSectionD"
#define KSegueShowSectionE              @"moveToSectionE"
#define KSegueShowSectionEFinalInterpration              @"moveToSectionEFinalInterpration"
#define KSegueShowSectionF              @"moveToSectionF"

#define KSegueShowFinalResult              @"moveToFinalResult"

#define kSequeShowResults               @"showResults"
#define kAlertTitle                     @"Alert!"
#define kAlertButtonOK                  @"Ok"
#define kAlertButtonCancel              @"Cancel"
#define kAlertGoToHome                  @"This method will remove all saved data. Are you sure you want to stop and go to home?"
#define kNameUnselectedImage            @"Selection-Unselected"
#define kNameSelectedImage              @"Selection-Selected"
#define kKeyQuestion                    @"Question"
#define kKeyQuestionNumber              @"QuestionNumber"
#define kKeyAgeSelected                 @"kKeyAgeSelected"
#define kAlertMessageAreYouSure         @"Are you sure?"

#define kDelayTime                      0.7 // For test // Logio // Chnage To 1

#endif /* Constants_h */
