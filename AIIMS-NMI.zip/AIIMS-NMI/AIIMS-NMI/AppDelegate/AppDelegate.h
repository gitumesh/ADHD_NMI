//
//  AppDelegate.h
//  AIIMS-NMI
//
//  Created by Umesh Sharma on 16/07/17.
//  Copyright © 2017 Umesh Sharma. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

